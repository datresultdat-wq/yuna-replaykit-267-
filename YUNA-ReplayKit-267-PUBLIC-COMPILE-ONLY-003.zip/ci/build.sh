#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'Apple macOS/Xcode runner required. No build or signing performed.' >&2
  exit 2
fi
xcodebuild -version
if [[ "${BUILD_MODE:-unsigned}" == unsigned ]]; then
  python3 ci/configure.py
  xcodebuild -project app/YunaCapture.xcodeproj -scheme YunaCapture -configuration Release \
    -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO build
  echo 'Unsigned compile only: NOT installable on iPad.'
  exit
fi
[[ "${BUILD_MODE}" == signed ]] || exit 2
: "${P12_BASE64:?}" "${P12_PASSWORD:?}" "${HOST_PROFILE_BASE64:?}" "${UPLOAD_PROFILE_BASE64:?}"
: "${TEAM_ID:?}" "${BUNDLE_ID:?}" "${APP_GROUP:?}" "${SIGN_IDENTITY:?}"
export SIGN_TEMP
SIGN_TEMP=$(mktemp -d)
chmod 700 "$SIGN_TEMP"
keychain="$SIGN_TEMP/yuna.keychain-db"
keypass=$(openssl rand -hex 32)
cleanup() { security delete-keychain "$keychain" >/dev/null 2>&1 || true; rm -rf "$SIGN_TEMP"; }
trap cleanup EXIT
python3 - <<'PY'
import os,base64
from pathlib import Path
for key,name in [('P12_BASE64','signing.p12'),('HOST_PROFILE_BASE64','host.mobileprovision'),('UPLOAD_PROFILE_BASE64','upload.mobileprovision')]:
 p=Path(os.environ['SIGN_TEMP'])/name
 p.write_bytes(base64.b64decode(os.environ[key],validate=True)); p.chmod(0o600)
PY
security create-keychain -p "$keypass" "$keychain"
security set-keychain-settings -lut 3600 "$keychain"
security unlock-keychain -p "$keypass" "$keychain"
security import "$SIGN_TEMP/signing.p12" -k "$keychain" -P "$P12_PASSWORD" -T /usr/bin/codesign -T /usr/bin/security >/dev/null
security set-key-partition-list -S apple-tool:,apple: -k "$keypass" "$keychain" >/dev/null
security list-keychains -d user -s "$keychain"
python3 ci/sign.py
