import unittest, copy, datetime, hashlib, json, plistlib
from pathlib import Path
from configure import configure, ROOT
from sign import validate

class BuildKitTests(unittest.TestCase):
    def setUp(self):
        self.p={'UUID':'fixture-only','TeamIdentifier':['TESTTEAM'], 'ApplicationIdentifierPrefix':['TESTTEAM'],
          'ExpirationDate':datetime.datetime(2099,1,1), 'Entitlements':{'application-identifier':'TESTTEAM.test.yuna',
          'com.apple.security.application-groups':['group.test.yuna'],'get-task-allow':False}}
    def check(self,p,method='app-store-connect'): return validate(p,'test.yuna','TESTTEAM','group.test.yuna',method)
    def test_valid(self): self.assertEqual(self.check(self.p),'fixture-only')
    def test_wrong_team(self):
        self.p['TeamIdentifier']=['OTHER']
        with self.assertRaises(ValueError): self.check(self.p)
    def test_wrong_bundle(self):
        self.p['Entitlements']['application-identifier']='TESTTEAM.*'
        with self.assertRaises(ValueError): self.check(self.p)
    def test_missing_group(self):
        self.p['Entitlements']['com.apple.security.application-groups']=[]
        with self.assertRaises(ValueError): self.check(self.p)
    def test_expired(self):
        self.p['ExpirationDate']=datetime.datetime(2000,1,1)
        with self.assertRaises(ValueError): self.check(self.p)
    def test_store_rejects_development(self):
        self.p['Entitlements']['get-task-allow']=True
        with self.assertRaises(ValueError): self.check(self.p)
    def test_ad_hoc_requires_devices(self):
        with self.assertRaises(ValueError): self.check(self.p,'release-testing')
        self.p['ProvisionedDevices']=['TEST-DEVICE']
        self.assertEqual(self.check(self.p,'release-testing'),'fixture-only')
    def test_fixed_sources(self):
        hashes=json.loads((ROOT/'baseline-sha256.json').read_text())
        for name,digest in hashes.items():
            if name=='YunaCapture.xcodeproj/project.pbxproj': continue
            self.assertEqual(hashlib.sha256((ROOT/'app'/name).read_bytes()).hexdigest(),digest,name)
    def test_configuration(self):
        configure('test.yuna','group.test.yuna')
        d=plistlib.loads((ROOT/'app/YunaCapture.xcodeproj/project.pbxproj').read_bytes())
        ids=[v['buildSettings']['PRODUCT_BUNDLE_IDENTIFIER'] for v in d['objects'].values()
             if v['isa']=='XCBuildConfiguration' and 'PRODUCT_BUNDLE_IDENTIFIER' in v['buildSettings']]
        self.assertEqual(set(ids),{'test.yuna','test.yuna.Upload'})
        configure('local.yuna.capture','group.local.yuna.capture')

if __name__=='__main__': unittest.main()
