"""On an ephemeral macOS runner: validate two official profiles, archive and export.
Certificate must already be imported into the temporary keychain by build.sh.
No Apple account login, registration, purchasing or automatic provisioning.
"""
import os, plistlib, subprocess, datetime
from pathlib import Path
from configure import ROOT, configure

def validate(profile, bundle, team, group, method):
    e = profile['Entitlements']
    if team not in profile.get('TeamIdentifier',[]): raise ValueError('Team mismatch')
    prefixes = profile.get('ApplicationIdentifierPrefix',[])
    if not any(e.get('application-identifier') == prefix+'.'+bundle for prefix in prefixes):
        raise ValueError('Exact App ID mismatch; wildcard not accepted')
    if group not in e.get('com.apple.security.application-groups',[]): raise ValueError('App Group missing')
    if profile['ExpirationDate'].replace(tzinfo=datetime.timezone.utc) <= datetime.datetime.now(datetime.timezone.utc):
        raise ValueError('Expired provisioning profile')
    if method=='app-store-connect' and ('ProvisionedDevices' in profile or e.get('get-task-allow')):
        raise ValueError('App Store profile required')
    if method=='release-testing' and (not profile.get('ProvisionedDevices') or e.get('get-task-allow')):
        raise ValueError('Ad Hoc distribution profile required')
    return profile['UUID']

def main():
    team,bundle,group = [os.environ[k] for k in ['TEAM_ID','BUNDLE_ID','APP_GROUP']]
    method=os.environ.get('EXPORT_METHOD','app-store-connect')
    if method not in ['app-store-connect','release-testing']: raise ValueError('Unsupported export method')
    temp=Path(os.environ['SIGN_TEMP'])
    profiles={}
    for name,file,bid in [('YunaCapture','host.mobileprovision',bundle),('YunaUpload','upload.mobileprovision',bundle+'.Upload')]:
        raw=subprocess.check_output(['security','cms','-D','-i',str(temp/file)])
        profile=plistlib.loads(raw)
        profiles[name]=validate(profile,bid,team,group,method)
        # Xcode 16+ and older profile search locations; only ephemeral runner files.
        for base in ['Library/Developer/Xcode/UserData/Provisioning Profiles','Library/MobileDevice/Provisioning Profiles']:
            out=Path.home()/base; out.mkdir(parents=True,exist_ok=True)
            (out/(profile['UUID']+'.mobileprovision')).write_bytes((temp/file).read_bytes())
    configure(bundle,group,team,profiles)
    build=ROOT/'build'; build.mkdir(exist_ok=True)
    options={'method':method,'teamID':team,'signingStyle':'manual','signingCertificate':os.environ['SIGN_IDENTITY'],
        'provisioningProfiles':{bundle:profiles['YunaCapture'],bundle+'.Upload':profiles['YunaUpload']},
        'destination':'export','manageAppVersionAndBuildNumber':False}
    (build/'ExportOptions.plist').write_bytes(plistlib.dumps(options))
    subprocess.run(['xcodebuild','-project',str(ROOT/'app/YunaCapture.xcodeproj'),'-scheme','YunaCapture',
        '-configuration','Release','-destination','generic/platform=iOS','-archivePath',str(build/'YunaCapture.xcarchive'),'archive'],check=True)
    subprocess.run(['xcodebuild','-exportArchive','-archivePath',str(build/'YunaCapture.xcarchive'),
        '-exportOptionsPlist',str(build/'ExportOptions.plist'),'-exportPath',str(build/'export')],check=True)

if __name__=='__main__': main()
