"""Validate actual Xcode output packaging, never treat unsigned output as installable."""
import json, plistlib, sys
from pathlib import Path

def verify(app):
    app=Path(app)
    host=plistlib.loads((app/'Info.plist').read_bytes())
    extensions=list((app/'PlugIns').glob('*.appex'))
    if len(extensions)!=1: raise ValueError('Exactly one embedded extension required')
    ext=extensions[0]
    info=plistlib.loads((ext/'Info.plist').read_bytes())
    if info['CFBundleIdentifier']!=host['CFBundleIdentifier']+'.Upload': raise ValueError('Bundle relationship mismatch')
    if info['YunaAppGroup']!=host['YunaAppGroup'] or not info['YunaAppGroup'].startswith('group.'):
        raise ValueError('App Group mismatch')
    if host['YunaUploadBundle']!=info['CFBundleIdentifier']: raise ValueError('Picker target mismatch')
    if info['NSExtension']['NSExtensionPointIdentifier']!='com.apple.broadcast-services-upload':
        raise ValueError('Wrong extension point')
    for folder,metadata in [(app,host),(ext,info)]:
        executable=folder/metadata['CFBundleExecutable']
        if not executable.is_file() or executable.stat().st_size==0: raise ValueError('Executable missing')
    if not (app/'renderer.html').is_file(): raise ValueError('Renderer resource missing')
    return {'host':host['CFBundleIdentifier'],'extension':info['CFBundleIdentifier'],
            'packaging':'PASS','signing':'NOT VERIFIED','installable':False,'native_live1':'NOT TESTED'}

if __name__=='__main__': print(json.dumps(verify(sys.argv[1]),indent=2))
