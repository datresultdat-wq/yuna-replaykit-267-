"""Build-only overlay. Never edits Swift, renderer, entitlements or baseline source."""
from pathlib import Path
import os, plistlib, re, xml.etree.ElementTree as ET, json, struct, zlib

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / 'app/YunaCapture.xcodeproj'

def configure(bundle, group, team='', profiles=None):
    if not re.fullmatch(r'[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+', bundle):
        raise ValueError('Invalid bundle identifier')
    if not re.fullmatch(r'group\.[A-Za-z0-9.-]+', group):
        raise ValueError('Invalid App Group')
    p = PROJECT / 'project.pbxproj'
    doc = plistlib.loads(p.read_bytes())
    targets = {v['name']: (k,v) for k,v in doc['objects'].items() if v['isa']=='PBXNativeTarget'}
    for name,(_,target) in targets.items():
        for cid in doc['objects'][target['buildConfigurationList']]['buildConfigurations']:
            s = doc['objects'][cid]['buildSettings']
            s['PRODUCT_BUNDLE_IDENTIFIER'] = bundle + ('.Upload' if name=='YunaUpload' else '')
            s['YUNA_APP_GROUP'] = group
            if name=='YunaUpload': s['TARGETED_DEVICE_FAMILY']='1,2'
            if name=='YunaCapture': s['ASSETCATALOG_COMPILER_APPICON_NAME']='AppIcon'
            if team: s['DEVELOPMENT_TEAM'] = team
            if profiles:
                s.update(CODE_SIGN_STYLE='Manual', CODE_SIGN_IDENTITY=os.environ['SIGN_IDENTITY'],
                         PROVISIONING_PROFILE_SPECIFIER=profiles[name])
    # Packaging icon only; original photograph and renderer remain byte-identical.
    assets=ROOT/'app/BuildAssets.xcassets'
    icons=assets/'AppIcon.appiconset'; icons.mkdir(parents=True,exist_ok=True)
    (assets/'Contents.json').write_text(json.dumps({'info':{'version':1,'author':'xcode'}}))
    images=[]
    for points,scale,idiom in [(20,1,'ipad'),(20,2,'ipad'),(29,1,'ipad'),(29,2,'ipad'),(40,1,'ipad'),(40,2,'ipad'),(76,1,'ipad'),(76,2,'ipad'),(83.5,2,'ipad'),(1024,1,'ios-marketing')]:
        size=int(points*scale); name=f'icon-{size}.png'
        def chunk(kind,data): return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
        raw=b''.join(b'\0'+bytes((29,48,72))*size for _ in range(size))
        (icons/name).write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b''))
        images.append({'idiom':idiom,'size':f'{points}x{points}','scale':f'{scale}x','filename':name})
    (icons/'Contents.json').write_text(json.dumps({'images':images,'info':{'version':1,'author':'xcode'}}))
    ref='A00000000000000000000001'; build='A00000000000000000000002'
    doc['objects'][ref]={'isa':'PBXFileReference','path':'BuildAssets.xcassets','sourceTree':'<group>','lastKnownFileType':'folder.assetcatalog'}
    doc['objects'][build]={'isa':'PBXBuildFile','fileRef':ref}
    project=doc['objects'][doc['rootObject']]
    children=doc['objects'][project['mainGroup']]['children']
    if ref not in children: children.append(ref)
    for phase in targets['YunaCapture'][1]['buildPhases']:
        resource=doc['objects'][phase]
        if resource['isa']=='PBXResourcesBuildPhase' and build not in resource['files']: resource['files'].append(build)
    p.write_bytes(plistlib.dumps(doc,sort_keys=False))
    scheme = ET.Element('Scheme', LastUpgradeVersion='2600',version='1.3')
    action = ET.SubElement(scheme,'BuildAction',parallelizeBuildables='YES',buildImplicitDependencies='YES')
    entries = ET.SubElement(action,'BuildActionEntries')
    entry = ET.SubElement(entries,'BuildActionEntry',buildForTesting='YES',buildForRunning='YES',
        buildForProfiling='YES',buildForArchiving='YES',buildForAnalyzing='YES')
    ET.SubElement(entry,'BuildableReference',BuildableIdentifier='primary',BlueprintIdentifier=targets['YunaCapture'][0],
        BuildableName='YunaCapture.app',BlueprintName='YunaCapture',ReferencedContainer='container:YunaCapture.xcodeproj')
    ET.SubElement(scheme,'ArchiveAction',buildConfiguration='Release',revealArchiveInOrganizer='YES')
    directory = PROJECT/'xcshareddata/xcschemes'
    directory.mkdir(parents=True,exist_ok=True)
    ET.ElementTree(scheme).write(directory/'YunaCapture.xcscheme',encoding='UTF-8',xml_declaration=True)

if __name__=='__main__':
    configure(os.getenv('BUNDLE_ID','local.yuna.capture'),os.getenv('APP_GROUP','group.local.yuna.capture'))
