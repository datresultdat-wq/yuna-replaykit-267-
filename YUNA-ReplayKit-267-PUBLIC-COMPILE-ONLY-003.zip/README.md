# YUNA ReplayKit 26.7 — Macなし Build / Signing Kit 001

確認日: 2026-09-18。Capture方式は採用候補として固定。元のYUNA-ReplayKit-267-PoC-001とRenderer28は無変更。
これはビルド準備パッケージです。署名済みIPAではありません。Swiftコンパイル・TestFlight upload・実機導入・Live1 audioApp取得は未実施です。

## 推奨する準備済み経路

private GitHub repository → standard macOS runner / Xcode → host+Broadcast Upload Extensionをbuild → 正規証明書と2つのprofileで署名 → App Store Connect → TestFlight → iPad。
Macを所有する必要はありません。実行先はAppleハードウェア上のmacOS CIです。GitHub接続、無料枠/課金停止設定、Apple署名資格の確認が必要です。
未接続のGitHubへpushしておらず、ワークフローは実行していません。公開repoへユナ画像を公開しません。

## 比較（buildと署名と配布を分離）

|方式|Mac所有 / Xcode実行環境|Program加入|無料条件 / 継続費|Extension・App Group・署名|iPad導入 / 操作 / 時間|
|---|---|---|---|---|---|
|無料Personal Team + Xcode|所有不要だがXcodeと実機導入接続が必要|不要|Xcode自体無料。クラウドMac費は別|公式最新capability表は無料Apple DeveloperにもApp groups=yes。既存2targetの無料署名は未検証|公式無料導入手順はXcode経由。7日で再provision。現在のiPad単独クラウド導入経路は未確定。所要時間未測定|
|Swift Playground / iPad|不要|開発とApp Store配布を区別。後者は加入が必要|アプリ自体無料|現在の2target .xcodeprojをそのままbuildしてBroadcast Upload Extensionを梱包する公式手順は確認できず。非対応と断定せず今回の導入経路として未成立|単純なapp playgroundの実行/提出機能だけでは現projectの署名・導入完了を証明しない|
|Xcode Cloud|所有不要だが最初のworkflowはXcodeで設定する公式手順|必要|会費内に25 compute時間/月。追加有料枠は使わない|Xcode project / extension build、署名・TestFlight経路あり。今回のproject build未実行|初回Xcode設定・Git連携が必要。その後Web管理。初回設定・処理時間は未測定|
|GitHub standard macOS CI + TestFlight|Mac所有不要|TestFlight配布に必要|private repo無料利用枠内かつ追加課金停止時のみCI追加費用0。会費別|既存Xcode projectをbuild、同じApp Groupをhostとextensionに指定、正規2profileで署名可能な構成を準備|初回GitHub/Apple設定→CI→Apple処理→iPad TestFlightでinstall。時間は未測定、CI上限20分は成功時間保証でない|
|App Store Connect / TestFlight単体|Mac所有不要|必要|Program会費に含む|ソースコードをbuildするサービスではない。署名済みbuildを受け取る|本人のinternal tester登録後iPadへ。build有効期間90日。外部testerは審査条件あり|
|その他クラウドmacOS/Xcode|Mac所有不要、正規Apple hardwareが必要|無料developmentか有料distributionかで別|サービスごとの利用料。今回新規有料契約は不採用|Xcodeと資格があれば同一projectを利用可能。今回その環境は未確保|リモートMacを得るだけでiPadへの署名・配布は解決しない。時間・費用を未契約サービスについて断定しない|

## 重要な公式資料の読み取り

Apple最新Supported capabilities (iOS)のApp groups行はADP/ADEP/Apple Developerの3列すべてyes。
したがって「App Group必須だから99ドル必須」とは判断しません。
無料Personal TeamはXcodeがApp IDs/devices/profilesを管理し、profileは7日。TestFlight / App Store Connect / Xcode Cloudは別のmembership条件。
今回確認できたMac所有不要の一貫した配布候補はクラウドXcode＋正規distribution署名＋TestFlight。ただし無料経路の不可能性を網羅的に実証したわけではありません。

## 費用と解禁範囲

新規の個人Apple Developer Programは年99 USD（地域別通貨・価格は本人の加入画面で確定）。月額課金ではないが新規課金なので購入しません。
加入済みまたは正当に参加できる既存organization teamがある場合、追加加入料が不要な可能性があります。現在の加入状況は未確認。
ProgramはCertificates/Identifiers/Profiles、App Store Connect/TestFlight、Xcode Cloud25時間/月を解禁。
非営利・教育・政府の条件を満たす法人にはfee waiverがあるが、一般個人向け無料加入ではありません。
加入しても純正Live1音声がaudioAppへ届くことは保証しません。解決するのは署名・配布資格です。

## パッケージ構成 / 固定保証

- app/: 固定PoCを複製。Swift/PCM/RMS/Renderer/entitlement内容はbyte一致。
- baseline-sha256.json: 元PoC全ファイルのhash。
- ci/configure.py: コピー側のbuild設定のみ変更。shared Scheme、host/extension別Bundle ID、共通Group、署名設定、配布用単色app icon、extension universal device設定。
- ci/build.sh: unsigned compile または正規manual signing archive/export。課金・登録・自動provisioning・uploadは行わない。
- ci/sign.py: 二つの署名profileを検査。同一Team、exact App ID、Group、期限、配布方式。秘密鍵は一時keychainへ入れ終了時削除。ephemeral runner専用。
- workflow: 手動dispatch限定、private repo限定、費用確認falseが初期値、20分上限。これ自体が課金上限ではないためGitHub側の無料枠・課金停止設定を先に確認。

## 実行前に必要な本人の資格・接続

1. GitHubを接続。private repoでActions残枠と有料超過停止を確認。接続後にWorkがrepoへ配置できる範囲を確認し、まずunsigned compileを実行。
2. Apple Developerの既存加入/team有無を確認。未加入なら勝手に加入しない。Apple Accountのパスワード/2FAをこのChatへ渡さない。
3. 正規distribution routeを使える場合、二つのexplicit App IDs（hostとhost.Upload）と一つのGroupを登録し両方へ有効化。証明書と各App ID用profileを用意。App Store Connectでhostのappレコードを作成。

CI Variables: TEAM_ID, BUNDLE_ID, APP_GROUP, SIGN_IDENTITY（証明書SHA1等）。
CI Secrets: P12_BASE64, P12_PASSWORD, HOST_PROFILE_BASE64, UPLOAD_PROFILE_BASE64。
秘密鍵/profileはchat、repo、artifactへ入れずSecretsへ。最初の証明書がまだ無ければ、認可された署名準備工程でCSR発行/Apple portal発行が別途必要。現在資格未確認なので実行していない。

このkitをprivate repositoryのrootへ配置。unsignedは証明書なしでbuild検証のみ（端末導入不可）。signedは正規profile取得後のみ。
App Store用IPAを得た後のuploadはApple公式altool/Transporterまたは認可済みCI uploadで行う。API Keyなど認可未設定のためupload自動化は今回未接続。App icon/metadata/SDK要件などはApple validation結果を確認する。
新iPadは同じTestFlight appを利用可能。Ad Hoc方式を選ぶ場合は新端末UDIDをprofileへ追加して再署名が必要。

## 検証結果 / Recovery

buildkit自動テスト9/9 PASS。bash構文PASS。固定元の全ファイルhash一致確認。
Apple compiler、codesign、App Store validation、TestFlight、実機captureはNOT RUN。
元PoC・Renderer28・Memory・Voice・27Adapterに変更なし。復旧は本buildkitを使わず元PoCを利用。

## 一次資料

- https://developer.apple.com/help/account/reference/supported-capabilities-ios/
- https://developer.apple.com/help/account/basics/about-your-developer-account/
- https://developer.apple.com/help/account/identifiers/register-an-app-group/
- https://developer.apple.com/help/account/membership/program-enrollment/
- https://developer.apple.com/help/account/membership/fee-waivers/
- https://developer.apple.com/xcode-cloud/
- https://developer.apple.com/documentation/xcode/configuring-your-first-xcode-cloud-workflow
- https://developer.apple.com/help/app-store-connect/test-a-beta-version/testflight-overview/
- https://developer.apple.com/help/app-store-connect/manage-builds/upload-builds/
- https://developer.apple.com/library/archive/documentation/General/Conceptual/ExtensibilityPG/ExtensionCreation.html
- https://developer.apple.com/documentation/swift-playgrounds/project-capabilities
- https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- https://docs.github.com/billing/managing-billing-for-github-actions/about-billing-for-github-actions
- https://docs.github.com/en/actions/how-tos/deploy/deploy-to-third-party-platforms/sign-xcode-applications


## 続行時の確定事項（2026-09-18追記）

ユーザーはApple Developer Program未加入。GitHubプラグインinstalled=trueを確認済み。
ただし現在のWorkの公開tool一覧にGitHub操作機能がなく、ghも未導入。未接続扱いで接続を繰り返させない。
repo作成・push・Actions実行は未実施。Workを開き直した後、GitHub toolが提供されたか確認して現在地から再開する。
通常ブラウザ自動操作への切替は行っていない。

.github/workflows/unsigned.ymlを追加。Apple認証情報を受け取らない独立workflow。
実際のXcode出力からhost/appex・picker宛先・Group一致・renderer同梱を検査し、短期保持の診断結果のみ返す。
成功しても未署名でありiPadへ導入可能とは判定しない。bundle検査器は構造fixtureの正常/Group不一致2ケースを確認済み。

無料署名の未解決点はXcode Personal Teamの本人ログインと実機pairing/導入。
Apple公式はXcode上でApple Accountへsign inし、Macへpairした実機で実行する手順を案内。
https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices
GitHub接続だけではAppleの署名済みprofileやiPadとのpairingは得られない。
無料Personal Teamは7日ごとに再provisionが必要。TestFlight配布とは別。

AltStore Classicの提供元手順も確認：Windows版はWindows PCへiPadを接続し、Apple Accountで認証する工程がある。
https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows
そのためiPad＋クラウドCIだけの導入経路を証明しない。Apple公開APIのみという条件を満たす署名実装だと確認できておらず、導入/Apple認証情報提供は実行しない。
Windows PCが使えるという未確認の前提を置かない。無料経路を方式不成立とも有料加入必須とも確定していない。

## Public repository execution note (2026-09-18)

The active repository is public by explicit user choice. The workflow gate that required `github.event.repository.private` and `no_cost_verified` has therefore been removed from the unsigned and build workflows so GitHub-hosted standard runners can execute in the public repository. No Apple signing secrets are included in this package; signed mode still requires repository Secrets/Variables and valid Apple credentials.

GitHub runner is pinned to `macos-26` because the current `macos-15` image defaults to Xcode 16.4; `macos-26` currently provides Xcode 26.6 by default and the iOS 26 SDK needed for this PoC.

## Public compile-only privacy variant
The embedded YUNA photograph is replaced by a 1x1 placeholder in this package. This does not test visual identity; it exists only to compile the host + Broadcast Upload Extension and verify bundle structure without publishing the user-provided image.
