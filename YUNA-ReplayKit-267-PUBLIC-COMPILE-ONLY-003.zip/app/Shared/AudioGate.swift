import Foundation

// Pure Swift port: no bridging header, C compiler, audio permission or network.
struct AudioGate {
    var state = -1
    var db = -120.0
    var level = 0.0
    var last = -1.0
    var above = -1.0
    var below = -1.0
    var label: String { state < 0 ? "unknown" : (state == 1 ? "true" : "false") }
    mutating func tick(_ now: Double) {
        if last < 0 || now < last || now-last > 0.8 { self = AudioGate() }
    }
    mutating func feed(_ rms: Double, _ now: Double) {
        guard rms.isFinite, rms >= 0, now.isFinite else { self = AudioGate(); return }
        tick(now)
        last = now
        db = 20 * log10(max(rms, 1e-6))
        let target = min(1, max(0, (db+55)/40))
        level = 0.35*target + 0.65*level
        if state == 1 {
            if db < -50 {
                if below < 0 { below = now }
                if now-below >= 0.30 { state = 0; above = -1 }
            } else { below = -1 }
        } else if db >= -42 {
            below = -1
            if above < 0 { above = now }
            if now-above >= 0.06 { state = 1 }
        } else {
            above = -1
            if below < 0 { below = now }
            if now-below >= 0.30 { state = 0 }
        }
        if state != 1 { level = 0 }
    }
    static func rms(_ samples: [Float]) -> Double {
        samples.withUnsafeBufferPointer { p in rmsFloat(p.baseAddress, p.count) }
    }
    static func rmsFloat(_ data: UnsafePointer<Float>?, _ count: Int) -> Double {
        guard let data, count > 0 else { return .nan }
        var sum = 0.0
        for i in 0..<count {
            let x = Double(data[i])
            guard x.isFinite else { return .nan }
            sum += x*x
        }
        return sqrt(sum/Double(count))
    }
    static func rmsInt16(_ data: UnsafePointer<Int16>?, _ count: Int) -> Double {
        guard let data, count > 0 else { return .nan }
        var sum = 0.0
        for i in 0..<count { let x = Double(data[i])/32768; sum += x*x }
        return sqrt(sum/Double(count))
    }
}

func runGateChecks() -> [String] {
    var results: [String] = []
    func check(_ name: String, _ ok: Bool) { results.append("\(ok ? "PASS" : "FAIL"): \(name)") }
    check("Float32 RMS", abs(AudioGate.rms([0.5, -0.5])-0.5) < 1e-9)
    let pcm: [Int16] = [16384, -16384]
    let intRMS = pcm.withUnsafeBufferPointer { AudioGate.rmsInt16($0.baseAddress, $0.count) }
    check("Int16 RMS", abs(intRMS-0.5) < 1e-9)
    check("空PCMはunknown扱い", AudioGate.rms([]).isNaN)
    var g = AudioGate()
    check("初期unknown", g.state == -1)
    g.feed(0, 1); g.feed(0, 1.31)
    check("受信した無音→idle", g.state == 0)
    g.feed(0.1, 1.40); g.feed(0, 1.42)
    check("短いクリックを除外", g.state == 0)
    g.feed(0.1, 1.50); g.feed(0.1, 1.57)
    check("音声区間→speaking", g.state == 1 && g.level > 0 && g.level <= 1)
    g.feed(0, 1.60); g.feed(0, 1.89)
    check("短い無音は保持", g.state == 1)
    g.feed(0, 1.91)
    check("300ms無音→idle", g.state == 0 && g.level == 0)
    g.feed(0.1, 2); g.feed(0.1, 2.07); g.feed(pow(10, -46.0/20), 2.2)
    check("ヒステリシス", g.state == 1)
    g.tick(3.01)
    check("データ途絶→unknown", g.state == -1 && g.level == 0)
    g.feed(.nan, 4)
    check("不正PCM→unknown", g.state == -1)
    return results
}
