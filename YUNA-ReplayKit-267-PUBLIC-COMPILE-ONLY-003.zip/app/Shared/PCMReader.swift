import Foundation
import CoreMedia
import AudioToolbox
// Extracted from existing CaptureMeter; algorithm unchanged.
enum PCMReader {
 static func rms(_ sample:CMSampleBuffer)->Double? {
        guard CMSampleBufferIsValid(sample), CMSampleBufferDataIsReady(sample),
              let format = CMSampleBufferGetFormatDescription(sample),
              let ptr = CMAudioFormatDescriptionGetStreamBasicDescription(format) else { return nil }
        let asbd = ptr.pointee
        let float32 = asbd.mFormatFlags & kAudioFormatFlagIsFloat != 0 && asbd.mBitsPerChannel == 32
        let int16 = asbd.mFormatFlags & kAudioFormatFlagIsSignedInteger != 0 && asbd.mBitsPerChannel == 16
        guard asbd.mFormatID == kAudioFormatLinearPCM,
              asbd.mFormatFlags & kAudioFormatFlagIsBigEndian == 0,
              asbd.mFormatFlags & kAudioFormatFlagIsPacked != 0,
              float32 || int16 else {
            return nil
        }
        var needed = 0
        var block: CMBlockBuffer?
        // The size query can return ArrayTooSmall while still reporting the size.
        _ = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sample,
            bufferListSizeNeededOut: &needed, bufferListOut: nil, bufferListSize: 0,
            blockBufferAllocator: nil, blockBufferMemoryAllocator: nil,
            flags: UInt32(kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment), blockBufferOut: nil)
        guard needed >= MemoryLayout<AudioBufferList>.size, needed < 65536 else { return nil }
        let raw = UnsafeMutableRawPointer.allocate(byteCount: needed, alignment: 16)
        defer { raw.deallocate() }
        let list = raw.bindMemory(to: AudioBufferList.self, capacity: 1)
        let result = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sample,
            bufferListSizeNeededOut: nil, bufferListOut: list, bufferListSize: needed,
            blockBufferAllocator: nil, blockBufferMemoryAllocator: nil,
            flags: UInt32(kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment), blockBufferOut: &block)
        guard result == noErr else { return nil }
        var squares = 0.0
        var total = 0
        for buffer in UnsafeMutableAudioBufferListPointer(list) {
            guard let data = buffer.mData else { continue }
            let width = float32 ? 4 : 2
            guard Int(buffer.mDataByteSize) % width == 0 else { continue }
            let count = Int(buffer.mDataByteSize)/width
            guard count > 0 else { continue }
            let value = float32
                ? AudioGate.rmsFloat(data.assumingMemoryBound(to: Float.self), count)
                : AudioGate.rmsInt16(data.assumingMemoryBound(to: Int16.self), count)
            guard value.isFinite else { return nil }
            squares += value*value*Double(count)
            total += count
        }
        // Keep the retained audio storage alive until the pointer reads complete.
        withExtendedLifetime(block) {}
        guard total > 0 else { return nil }
        return sqrt(squares/Double(total))
 }
}
