import Foundation

struct MeterFrame: Codable {
    let source: String
    let state: Int
    let volume: Double
    let sequence: Int
    let timestamp: Double
    let audioAppCount: Int
    let audioMicDiscarded: Int
    let status: String
}

enum FrameStore {
    static var url: URL? {
        guard let group=Bundle.main.object(forInfoDictionaryKey:"YunaAppGroup") as? String else { return nil }
        return FileManager.default.containerURL(forSecurityApplicationGroupIdentifier:group)?.appendingPathComponent("yuna-meter.json")
    }
    static func write(_ frame: MeterFrame) throws {
        guard let url else { throw NSError(domain:"Yuna",code:1,userInfo:[NSLocalizedDescriptionKey:"App Group provisioning unavailable"]) }
        try JSONEncoder().encode(frame).write(to:url,options:.atomic)
    }
    static func read() throws -> MeterFrame {
        guard let url else { throw NSError(domain:"Yuna",code:1) }
        let size=(try url.resourceValues(forKeys:[.fileSizeKey])).fileSize ?? 0
        guard size<=4096 else { throw NSError(domain:"Yuna",code:2) }
        return try JSONDecoder().decode(MeterFrame.self,from:Data(contentsOf:url))
    }
}
