import SwiftUI
import WebKit

struct CaptureFrame: Equatable {
    var state = -1
    var volume = 0.0
    var sequence = 0
    var timestamp = Date().timeIntervalSince1970 * 1000
}

// This WKWebView hosts bundled renderer code only. It never opens ChatGPT.
struct LocalRenderer: UIViewRepresentable {
    var frame: CaptureFrame
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> WKWebView {
        let view = WKWebView()
        view.navigationDelegate = context.coordinator
        view.scrollView.isScrollEnabled = false
        if let url = Bundle.main.url(forResource: "renderer", withExtension: "html"),
           let html = try? String(contentsOf: url, encoding: .utf8) {
            view.loadHTMLString(html, baseURL: nil)
        }
        return view
    }
    func updateUIView(_ view: WKWebView, context: Context) {
        context.coordinator.latest = frame
        context.coordinator.flush(view)
    }
    class Coordinator: NSObject, WKNavigationDelegate {
        var ready = false
        var inFlight = false
        var latest = CaptureFrame()
        var sent = -1
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { ready = true; flush(webView) }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            decisionHandler(navigationAction.request.url?.absoluteString == "about:blank" ? .allow : .cancel)
        }
        func flush(_ view: WKWebView) {
            guard ready, !inFlight, latest.sequence != sent else { return }
            let f = latest
            let value: [String: Any] = ["source":"system_audio", "state":f.state,"volume":f.volume,"sequence":f.sequence,"timestamp":f.timestamp]
            guard let data = try? JSONSerialization.data(withJSONObject:value), let json=String(data:data,encoding:.utf8) else { return }
            inFlight = true; sent = f.sequence
            view.evaluateJavaScript("window.receiveCaptureFrame(\(json))") { [weak self, weak view] _, _ in
                guard let self, let view else { return }
                self.inFlight = false
                self.flush(view)
            }
        }
    }
}
