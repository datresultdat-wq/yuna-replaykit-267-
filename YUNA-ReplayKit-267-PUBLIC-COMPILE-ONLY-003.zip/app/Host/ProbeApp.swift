import SwiftUI
import ReplayKit
import Foundation

@main struct ProbeApp:App {var body:some Scene{WindowGroup{ProbeView()}}}
struct BroadcastPicker:UIViewRepresentable {
    func makeUIView(context:Context)->RPSystemBroadcastPickerView {
        let view=RPSystemBroadcastPickerView(frame:CGRect(x:0,y:0,width:64,height:64))
        view.preferredExtension=Bundle.main.object(forInfoDictionaryKey:"YunaUploadBundle") as? String
        view.showsMicrophoneButton=false
        return view
    }
    func updateUIView(_ uiView:RPSystemBroadcastPickerView,context:Context){}
}
struct ProbeView:View {
    @State private var frame=CaptureFrame()
    @State private var status="未開始：Live1音声取得は未確認"
    @State private var count=0
    private let timer=Timer.publish(every:0.1,on:.main,in:.common).autoconnect()
    var body:some View{
        VStack(spacing:12){
            LocalRenderer(frame:frame)
            Text(status).font(.caption)
            Text("audioApp buffers: \(count)").monospaced()
            BroadcastPicker().frame(width:64,height:64)
            Text("上のApple画面共有ボタンから開始。ChatGPTを隣に表示し純正Live1を使用。音声・映像は保存／送信しません。").font(.caption)
        }.padding().onReceive(timer){_ in poll()}
    }
    private func poll(){
        let now=Date().timeIntervalSince1970*1000
        do {
            let f=try FrameStore.read()
            guard f.source=="system_audio",[-1,0,1].contains(f.state),f.volume.isFinite,(0...1).contains(f.volume),f.timestamp<=now+250,now-f.timestamp<800 else {unknown("信号途絶・unknown",now);return}
            count=f.audioAppCount;status="\(f.status) / mic破棄 \(f.audioMicDiscarded)"
            frame=CaptureFrame(state:f.state,volume:f.volume,sequence:f.sequence,timestamp:f.timestamp)
        }catch{unknown(FrameStore.url == nil ? "App Group署名設定なし：実機導入未完了" : "共有待ち・unknown",now)}
    }
    private func unknown(_ text:String,_ now:Double){status=text;frame=CaptureFrame(state:-1,volume:0,sequence:max(frame.sequence+1,Int(now)),timestamp:now)}
}
