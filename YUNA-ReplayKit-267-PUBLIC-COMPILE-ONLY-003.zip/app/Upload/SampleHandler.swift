import ReplayKit
import CoreMedia
import AudioToolbox
import Foundation

final class SampleHandler: RPBroadcastSampleHandler {
    private let serial=DispatchQueue(label:"yuna.replaykit.meter")
    private var gate=AudioGate()
    private var timer: DispatchSourceTimer?
    private var count=0, discarded=0, sequence=0
    private var active=false, paused=false
    override func broadcastStarted(withSetupInfo setupInfo: [String:NSObject]?) {
        serial.sync {
            gate=AudioGate(); count=0; discarded=0; active=true; paused=false
            publish("waiting_audioApp")
            guard active else { return }
            let t=DispatchSource.makeTimerSource(queue:serial)
            t.schedule(deadline:.now(),repeating:.milliseconds(100))
            t.setEventHandler { [weak self] in
                guard let self, self.active else { return }
                self.gate.tick(ProcessInfo.processInfo.systemUptime)
                self.publish(self.paused ? "paused" : self.gate.state == -1 ? "no_audioApp_or_stale" : "audioApp_received")
            }
            timer=t; t.resume()
        }
    }
    override func broadcastPaused(){serial.sync{paused=true;gate=AudioGate();publish("paused")}}
    override func broadcastResumed(){serial.sync{paused=false;gate=AudioGate();publish("waiting_audioApp")}}
    override func broadcastFinished(){serial.sync{active=false;timer?.cancel();timer=nil;gate=AudioGate();publish("stopped")}}
    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType:RPSampleBufferType){
        // Synchronous bounded processing: no queued PCM, no recording or upload.
        serial.sync {
            guard active,!paused else{return}
            if sampleBufferType == .audioMic {discarded+=1;return}
            guard sampleBufferType == .audioApp else{return}
            guard let rms=PCMReader.rms(sampleBuffer) else {gate=AudioGate();publish("unsupported_or_invalid_pcm");return}
            count+=1;gate.feed(rms,ProcessInfo.processInfo.systemUptime)
        }
    }
    private func publish(_ status:String){
        let timestamp=Date().timeIntervalSince1970*1000
        sequence=max(sequence+1,Int(timestamp))
        do {try FrameStore.write(MeterFrame(source:"system_audio",state:gate.state,volume:gate.level,sequence:sequence,timestamp:timestamp,audioAppCount:count,audioMicDiscarded:discarded,status:status))}
        catch {active=false;timer?.cancel();timer=nil;finishBroadcastWithError(error)}
    }
}
