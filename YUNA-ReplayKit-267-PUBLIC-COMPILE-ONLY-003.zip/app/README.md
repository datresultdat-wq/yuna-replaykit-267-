# YUNA ReplayKit compatibility adapter for iPadOS 26.7

2026-09-18. Status: implementation prepared, Apple build/sign/install environment missing. **26.7 Live1 capture NOT tested; neither PASS nor API-impossible.** This archive is source, NOT an installable IPA or App Playground. No Mac ownership is assumed. Do not ask the user to start a nonexistent installed broadcast provider.

## Implemented path

Apple RPSystemBroadcastPickerView → embedded Broadcast Upload Extension → RPBroadcastSampleHandler → audioApp only → existing CMSampleBuffer PCM extraction / Swift AudioGate → numeric snapshot in private App Group → foreground host WKWebView → unchanged Control Bridge / Renderer28.

audioMic and video are discarded before reading sample content. Hiding the mic button is not asserted to disable a previously enabled system mic; separate audioMic buffers are unconditionally ignored and counted. No AVAudioSession category/activation changes, microphone request, playback, PCM disk recording, upload or ChatGPT inspection. Only latest state, volume, timestamp, sequence and counters are persisted, atomically overwritten at ≤10Hz. Watchdog resets stale input to unknown; Renderer uses idle fallback, never calls missing audio measured silence. Other apps/notification audio can trigger speaking. Whether Live1 appears in audioApp or is omitted/muted remains the central device experiment.

## Route comparison

| Public route | Decision |
|---|---|
| RPScreenRecorder.startCapture | Own-app capture API; not represented as capturing ChatGPT from a Playground host. |
| Broadcast Upload Extension / RPBroadcastSampleHandler | Implemented 26.7 candidate, not discarded for deprecation. Requires installed, signed extension and host. |
| audioApp / audioMic | Process only audioApp; mic and video discarded. No speaker attribution guarantee. |
| AVAudioSession | Does not itself supply another app's PCM; leave untouched to minimize interference with Live1. |
| App Group IPC | Implemented numeric-only private container. Both targets need registered group and matching entitlements/profile. |
| Local WebSocket | Transport cannot supply capture or solve extension installation. Not added: extra port/auth/lifecycle complexity without removing current blocker. |
| ScreenCaptureKit | Existing 27 adapter retained separately; never run or report PASS on 26.7. |

## A/B/C/D distinction

A: Apple API impossibility NOT established. B: iPadOS26.7 impossibility NOT established. C: current Playground has iOS26 SDK, so the SDK major version itself is NOT the blocker for ReplayKit. However official Playground-only Broadcast Upload Extension target/sign/install workflow has not been established. D: this Linux execution environment has no Swift compiler, Apple SDK, xcodebuild, Apple signing identity/profile or iPad installation channel. This is the actual stop point. Generated Xcode project is a portable standard source format, NOT an instruction to buy or own a Mac. No paid cloud build, Apple subscription or tool installation was purchased.

## Build/distribution readiness

Two targets are provided with embedded extension, sample-buffer processing plist and App Group entitlement. Bundle/group names are example personal identifiers, not registered identities. A permitted Apple build/signing service must register/replace identifiers and sign both targets with the same existing team/group. No signing secrets are included. New cost requires stopping; no subscription assumed.

`python3 prepare_project.py` regenerates plists/project with Python only (does not build iOS). When an authorized Apple SDK builder is available, build target `YunaCapture` for iphoneos; unsigned source compile can be checked with `xcodebuild -project YunaCapture.xcodeproj -target YunaCapture -sdk iphoneos CODE_SIGNING_ALLOWED=NO build`. Unsigned output cannot be installed. There is currently no verified Mac-free install path available to this session. Do not disguise this as an IPA ready for Files/Playground.

## One device session, only AFTER signed installation

1. Open YunaCapture and ChatGPT side by side. In YunaCapture tap the system broadcast icon, select YunaUpload if shown, then Apple's Start Broadcast. Keep microphone off if the system displays that control.
2. Start native GPT-Live-1 in Yuna Project and have one short exchange. Watch audioApp count, speaking/idle and mouth response; speak once while Live1 is silent to check for microphone contamination. Do not save audio.
3. Stop broadcast with Apple's capture indicator/control. Confirm unknown/fallback and unchanged normal Live1 conversation.

This is 3 action groups, not a claim of 3 taps. Exact OS UI and daily action count not yet measured. Visible renderer requires foreground/multitasking; background host display is not promised. Native output-only capture cannot infer user listening. If no audioApp arrives, record this as unreceived/unknown, NOT silence or automatic proof of general API impossibility. Check permission, extension process and app-audio availability first. If Live1 is excluded, do not bypass protection.

## Verification run

- Original C gate suite PASS (RMS/attack/release/hysteresis/stale/invalid).
- 40 synthetic PCM frames through original C gate → JS adapter → unchanged Bridge / Renderer PASS; not ReplayKit acquisition or Swift execution.
- Python static project check PASS: targets/embed/plist/group/reuse/source guards. Not a Swift compiler test.
- Renderer/Memory/Voice production repo untouched in this task; its existing 208/208 result remains the baseline, not counted as capture validation.

## Recovery / 27 path

Stop the system broadcast; the renderer watchdog falls back. No backend or Voice rollback required. Existing YUNA-Live-Capture-Adapter-001.zip contains the ScreenCaptureKit27 branch. Both feed the same numeric contract and exact Renderer28 HTML. Keep 26.7 candidate pending installation, not disproven; only classify capture after real buffers are observed.

## Apple primary references

- https://developer.apple.com/documentation/replaykit/rpbroadcastsamplehandler — subclass callbacks, serialized calls and sample-buffer mode.
- https://developer.apple.com/documentation/replaykit/rpsamplebuffertype/audioapp — app-origin audio buffer.
- https://developer.apple.com/documentation/replaykit/rpsystembroadcastpickerview — system user selection and preferred extension.
- https://developer.apple.com/documentation/replaykit/rpscreenrecorder — own-app recording scope.
- https://developer.apple.com/documentation/xcode/configuring-app-groups — host/extension shared container and registered group requirements.

Official Markdown retrieved and read. API listing is not evidence of ChatGPT-specific PCM delivery. No new fee, private API, scraping, jailbreak, bypass, Memory mutation or renderer changes.
