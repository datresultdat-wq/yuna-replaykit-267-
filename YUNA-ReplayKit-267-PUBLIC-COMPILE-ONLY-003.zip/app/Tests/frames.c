#include "AudioGate.h"
#include <stdio.h>
int main(void){AudioGate g=gate_create();float quiet[2]={0,0},sound[2]={.12f,-.12f};
 for(int i=0;i<40;i++){double t=i*.1;
  if(i<30)gate_feed(&g,pcm_rms_f32(i>=5&&i<20?sound:quiet,2),t);else gate_tick(&g,t);
  printf("{\"source\":\"system_audio\",\"sequence\":%d,\"state\":%d,\"volume\":%.6f,\"timestamp\":%d}\n",i,g.state,g.level,100000+i*100);
 }return 0;}
