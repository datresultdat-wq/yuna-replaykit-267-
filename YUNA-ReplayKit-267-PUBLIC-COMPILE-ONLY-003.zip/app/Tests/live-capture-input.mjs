// Local native producer only; no network listener, audio or ChatGPT access.
export function createCaptureInput(bridge,{now=Date.now}={}){
 let sequence=-1;
 return {receive(frame){
  if(!frame || frame.source!=='system_audio' || !Number.isSafeInteger(frame.sequence) || frame.sequence<=sequence || ![-1,0,1].includes(frame.state) || !Number.isFinite(frame.volume) || frame.volume<0 || frame.volume>1 || !Number.isFinite(frame.timestamp))return {ok:false,reason:'invalid_frame'};
  const at=now();if(frame.timestamp>at+250 || at-frame.timestamp>=800)return {ok:false,reason:'stale_frame'};
  sequence=frame.sequence;
  if(frame.state===-1){bridge.resetInput();return {ok:true,unknown:true};}
  return bridge.accept({conversation_state:frame.state===1?'speaking':'idle',expression:'neutral',volume:frame.state===1?frame.volume:0,timestamp:frame.timestamp},at);
 }};
}
