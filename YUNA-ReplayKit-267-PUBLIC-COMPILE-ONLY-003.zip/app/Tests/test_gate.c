#include "AudioGate.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
int main(void) {
    AudioGate g=gate_create(); assert(g.state==-1);
    float f[]={0.5f,-0.5f}; short s[]={16384,-16384};
    assert(fabs(pcm_rms_f32(f,2)-0.5)<1e-9);
    assert(fabs(pcm_rms_i16(s,2)-0.5)<1e-9);
    assert(isnan(pcm_rms_f32(NULL,0)));
    gate_feed(&g,0,1); gate_feed(&g,0,1.31); assert(g.state==0);
    gate_feed(&g,0.1,1.40); gate_feed(&g,0,1.42); assert(g.state==0); // Click rejected.
    gate_feed(&g,0.1,1.50); gate_feed(&g,0.1,1.57); assert(g.state==1);
    assert(g.level>0 && g.level<=1);
    gate_feed(&g,0,1.60); gate_feed(&g,0,1.89); assert(g.state==1);
    gate_feed(&g,0,1.91); assert(g.state==0 && g.level==0);
    gate_feed(&g,0.1,2); gate_feed(&g,0.1,2.07); assert(g.state==1);
    gate_feed(&g,pow(10,-46.0/20),2.2); assert(g.state==1); // Hysteresis.
    gate_tick(&g,3.01); assert(g.state==-1 && g.level==0); // Missing isn't silence.
    gate_feed(&g,0.1,4); gate_feed(&g,0.1,4.07); assert(g.state==1);
    gate_feed(&g,NAN,4.1); assert(g.state==-1);
    gate_feed(&g,INFINITY,4.2); assert(g.state==-1);
    gate_feed(&g,-1,4.3); assert(g.state==-1);
    gate_feed(&g,1,5); gate_feed(&g,1,5.07); assert(g.level<=1);
    gate_tick(&g,4); assert(g.state==-1); // Clock discontinuity.
    puts("PASS: PCM RMS, impulse rejection, attack, release, hysteresis, level bounds, stale data, invalid values, clock reset");
}
