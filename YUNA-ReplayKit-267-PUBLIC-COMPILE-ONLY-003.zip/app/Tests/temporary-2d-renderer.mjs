import {createFaceMotion} from './photo-face-motion.mjs';
// No face synthesis, audio analysis or Memory access. Optional bounded photo resampling.
export function createTemporary2DRenderer({image,face=null,now=()=>performance.now(),reducedMotion=()=>false}){
 let state='idle',expression='neutral',volume=0,last=now(),phase=0,intensity=0,blend=0;
 const motion=createFaceMotion();let faceState={},lastFace=0;
 const reset=()=>{image.style.transform='none';face?.clear();};
 return {
  setConversationState(v){state=v;image.dataset.state=v;},
  setVolume(v){volume=Number.isFinite(v)?Math.max(0,Math.min(1,v)):0;},
  setExpression(v){expression=v;image.dataset.expression=v;},
  setSpeaking(v){image.dataset.speaking=String(v);},
  setBlendChannels(){
   const at=now(),dt=Math.max(0,Math.min(50,at-last));last=at;phase+=dt/1000;
   intensity+=(volume-intensity)*(1-Math.exp(-dt/280));
   const target=state==='speaking'?.45+.55*intensity:state==='listening'?.12:.24;
   blend+=(target-blend)*(1-Math.exp(-dt/400));
   faceState=motion.step({dt,state,volume,expression,reduced:reducedMotion()});
   if(reducedMotion()){reset();return;}
   const x=.24*blend*Math.sin(phase*.48),y=.85*blend*Math.sin(phase*1.1);
   const scale=1.002+.0012*blend*(.5+.5*Math.sin(phase*.8));
   image.style.transform=`translate3d(${x.toFixed(4)}px,${y.toFixed(4)}px,0) scale(${scale.toFixed(6)})`;
   if(face&&at-lastFace>=33){face.draw(faceState);lastFace=at;}
  },
  diagnostics(){return {state,expression,volume,intensity,...faceState};},
  dispose(){intensity=0;blend=0;motion.reset();reset();}
 };
}
