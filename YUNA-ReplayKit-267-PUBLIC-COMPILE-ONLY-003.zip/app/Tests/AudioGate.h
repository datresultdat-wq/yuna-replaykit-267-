#ifndef AUDIO_GATE_H
#define AUDIO_GATE_H
#include <stddef.h>
// state: -1 = unknown, 0 = measured idle, 1 = sound active (not speaker identity).
typedef struct { int state; double db, level, last, above, below; } AudioGate;
AudioGate gate_create(void);
void gate_feed(AudioGate *g, double rms, double now);
void gate_tick(AudioGate *g, double now);
double pcm_rms_f32(const float *data, size_t count);
double pcm_rms_i16(const short *data, size_t count);
#endif
