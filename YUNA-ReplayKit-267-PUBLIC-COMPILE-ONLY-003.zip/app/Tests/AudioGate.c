#include "AudioGate.h"
#include <math.h>
AudioGate gate_create(void) { return (AudioGate){-1,-120,0,-1,-1,-1}; }
void gate_tick(AudioGate *g, double now) {
    if (g->last < 0 || now < g->last || now-g->last > 0.8) *g=gate_create();
}
void gate_feed(AudioGate *g, double rms, double now) {
    if (!isfinite(rms) || rms < 0 || !isfinite(now)) { *g=gate_create(); return; }
    gate_tick(g, now);
    g->last=now;
    g->db=20*log10(fmax(rms,1e-6));
    double target=fmin(1,fmax(0,(g->db+55)/40));
    g->level=0.35*target+0.65*g->level;
    if (g->state==1) {
        if (g->db < -50) {
            if (g->below < 0) g->below=now;
            if (now-g->below >= 0.30) { g->state=0; g->above=-1; }
        } else g->below=-1;
    } else if (g->db >= -42) {
        g->below=-1;
        if (g->above < 0) g->above=now;
        if (now-g->above >= 0.06) g->state=1;
    } else {
        g->above=-1;
        if (g->below < 0) g->below=now;
        if (now-g->below >= 0.30) g->state=0;
    }
    if (g->state!=1) g->level=0;
}
double pcm_rms_f32(const float *data,size_t count) {
    if (!data || !count) return NAN;
    double sum=0;
    for(size_t i=0;i<count;i++){ if(!isfinite(data[i])) return NAN; double x=data[i]; sum+=x*x; }
    return sqrt(sum/count);
}
double pcm_rms_i16(const short *data,size_t count) {
    if (!data || !count) return NAN;
    double sum=0;
    for(size_t i=0;i<count;i++){ double x=data[i]/32768.0; sum+=x*x; }
    return sqrt(sum/count);
}
