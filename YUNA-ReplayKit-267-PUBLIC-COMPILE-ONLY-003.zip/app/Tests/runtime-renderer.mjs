import {AvatarControlBridge, EXPRESSIONS} from './control-bridge.mjs';

// Renderer receives controls only. It has no Memory/Voice credentials or session API.
export function createRendererAdapter(renderer) {
  for(const key of ['setConversationState','setVolume','setExpression','setSpeaking'])
    if(typeof renderer?.[key]!=='function')throw new Error('INVALID_RENDERER_CONTRACT');
  return {render(s){renderer.setConversationState(s.conversation_state);renderer.setVolume(s.volume);
    renderer.setExpression(s.expression);renderer.setSpeaking(s.conversation_state==='speaking');
    renderer.setBlendChannels?.({mouth_openness:s.mouth_openness,state_weights:s.state_weights,expression_weights:s.expression_weights});
  },dispose(){renderer.dispose?.();}};
}
export function createGuavaAdapter(callbacks){
  // Binding stub only. No GUAVA inference, assets, playback or timing assumptions.
  return createRendererAdapter(callbacks);
}
export function createRuntimeRenderer({renderer,now=Date.now,onSnapshot=()=>{}}){
  const bridge=new AvatarControlBridge();
  let connected=false,microphone=false,state='idle',volume=0,expression='neutral',last=-Infinity;
  const logs=[];
  function record(type,value){logs.push({timestamp:now(),type,value});if(logs.length>160)logs.shift();}
  function event(name,data={}){
    if(name==='connection_state'){connected=data.state==='connected';if(!connected){state='idle';volume=0;microphone=false;}}
    if(name==='microphone_state'){microphone=data.state==='on';if(state!=='speaking')state=connected&&microphone?'listening':'idle';}
    if(name==='state')state=data.state==='speaking'&&connected?'speaking':'idle';
    if(name==='user_speech'&&connected){state=data.active?'listening':'idle';volume=0;}
    if(name==='audio_level')volume=connected&&Number.isFinite(data.level)?Math.max(0,Math.min(1,data.level)):0;
    if(name==='expression'&&EXPRESSIONS.includes(data.expression))expression=data.expression;
    if(['connection_state','microphone_state','state','expression','user_speech'].includes(name))record(name,{state,expression,connected});
  }
  function tick(){const at=now();if(at>last){bridge.accept({conversation_state:connected?state:'idle',expression,volume:state==='speaking'?volume:0,timestamp:at},at);last=at;}
    const snapshot=bridge.tick(at);try{onSnapshot({...snapshot,connected});}catch{}return snapshot;}
  function replaceRenderer(next){bridge.setAdapter(next?createRendererAdapter(next):null);record('renderer',next?'connected':'disconnected');}
  replaceRenderer(renderer);
  return {event,tick,replaceRenderer,logs:()=>structuredClone(logs),dispose:()=>bridge.dispose()};
}
