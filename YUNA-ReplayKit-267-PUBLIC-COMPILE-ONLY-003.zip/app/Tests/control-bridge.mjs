export const STATES = Object.freeze(['idle', 'listening', 'speaking']);
export const EXPRESSIONS = Object.freeze(['neutral', 'small_smile', 'amused', 'concerned', 'surprised', 'annoyed']);
const clamp = v => Math.max(0, Math.min(1, v));
const approach = (v, target, dt, tau) => target + (v-target)*Math.exp(-dt/tau);
const weights = (names, selected) => Object.fromEntries(names.map(n => [n, Number(n===selected)]));
const VARIANTS = {
  idle: ['rest', 'slow_breath', 'soft_glance'],
  listening: ['attentive', 'tiny_nod', 'slight_tilt'],
  speaking: ['soft_emphasis', 'asymmetric_gesture', 'brief_stillness']
};

/** Signal-neutral control layer. No microphone, network, memory backend or renderer dependency.
 * timestamp is epoch milliseconds. Call tick(now) with an increasing local epoch clock.
 * Source handover requires resetInput(); timestamps are ordered within one source session.
 */
export class AvatarControlBridge {
  constructor({timeoutMs=1800, futureToleranceMs=250, random=Math.random}={}) {
    if (!(timeoutMs>0) || !(futureToleranceMs>=0)) throw new Error('Invalid timing configuration');
    this.timeoutMs=timeoutMs; this.futureToleranceMs=futureToleranceMs; this.random=random;
    this.stateWeights=weights(STATES,'idle'); this.expressionWeights=weights(EXPRESSIONS,'neutral');
    this.input=null; this.lastTimestamp=-Infinity; this.lastTick=null;
    this.volume=0; this.mouth=0; this.variantState='idle'; this.variantIndex=0;
    this.variantSince=null; this.variantAt=null; this.lastNow=null;
    this.previousVariant='rest'; this.disposed=false; this.adapter=null; this.adapterError=null;
  }
  accept(frame, now=Date.now()) {
    if (this.disposed) return {ok:false, reason:'disposed'};
    if (!frame || !STATES.includes(frame.conversation_state) || !EXPRESSIONS.includes(frame.expression) ||
        !Number.isFinite(frame.volume) || !Number.isFinite(frame.timestamp) || !Number.isFinite(now))
      return {ok:false, reason:'invalid_frame'};
    if (frame.timestamp<=this.lastTimestamp) return {ok:false, reason:'out_of_order'};
    if (frame.timestamp>now+this.futureToleranceMs) return {ok:false, reason:'future_timestamp'};
    if (now-frame.timestamp>=this.timeoutMs) return {ok:false, reason:'stale_timestamp'};
    // Copy only the contract. An invalid frame never refreshes the watchdog.
    this.input={conversation_state:frame.conversation_state, expression:frame.expression,
      volume:clamp(frame.volume), timestamp:frame.timestamp, receivedAt:now};
    this.lastTimestamp=frame.timestamp;
    return {ok:true};
  }
  resetInput() { this.input=null; this.lastTimestamp=-Infinity; }
  setAdapter(adapter) {
    if (this.disposed) throw new Error('Bridge disposed');
    if (adapter && typeof adapter.render!=='function') throw new Error('Adapter requires render(snapshot)');
    if (this.adapter!==adapter) this.adapter?.dispose?.();
    this.adapter=adapter; this.adapterError=null;
  }
  tick(now=Date.now()) {
    if (this.disposed) throw new Error('Bridge disposed');
    if (!Number.isFinite(now)) throw new Error('Invalid clock');
    if (this.lastTick!==null && now<this.lastTick) throw new Error('Clock moved backwards');
    const dt=this.lastTick===null?0:now-this.lastTick;
    this.lastTick=now;
    const live=!!this.input && now-this.input.receivedAt<this.timeoutMs && now-this.input.timestamp<this.timeoutMs;
    const state=live?this.input.conversation_state:'idle';
    const expression=live?this.input.expression:'neutral';
    for (const s of STATES) this.stateWeights[s]=approach(this.stateWeights[s],Number(s===state),dt,180);
    for (const e of EXPRESSIONS) this.expressionWeights[e]=approach(this.expressionWeights[e],Number(e===expression),dt,110);
    const volumeTarget=live?this.input.volume:0;
    this.volume=approach(this.volume,volumeTarget,dt,volumeTarget>this.volume?65:160);
    // Gate by the authoritative state. Listening is never mouth animation from mic volume.
    const target=state==='speaking'?Math.pow(clamp((this.volume-0.025)/0.975),0.7):0;
    this.mouth=approach(this.mouth,target,dt,target>this.mouth?45:100);
    if (Math.abs(this.mouth)<1e-6) this.mouth=0;
    if (this.variantAt===null || state!==this.variantState || now>=this.variantAt) {
      const choices=VARIANTS[state];
      this.previousVariant=VARIANTS[this.variantState][this.variantIndex];
      // Select a different variation; no frame-rate-dependent random walk.
      const old=state===this.variantState?this.variantIndex:-1;
      const candidates=choices.map((_,i)=>i).filter(i=>i!==old);
      const r=clamp(Number(this.random())||0);
      this.variantIndex=candidates[Math.min(candidates.length-1,Math.floor(r*candidates.length))];
      this.variantState=state; this.variantSince=now;
      const base=state==='idle'?5500:state==='listening'?4000:2800;
      this.variantAt=now+base+clamp(Number(this.random())||0)*2200;
    }
    const result={
      conversation_state:state, expression, volume:clamp(this.volume), timestamp:now,
      input_status:live?'live':'unknown', fallback:!live, source_timestamp:this.input?.timestamp??null,
      state_weights:{...this.stateWeights}, expression_weights:{...this.expressionWeights},
      mouth_openness:clamp(this.mouth),
      variation:{id:VARIANTS[state][this.variantIndex], previous:this.previousVariant,
        blend:clamp((now-this.variantSince)/450), elapsed_ms:now-this.variantSince},
      adapter_error:this.adapterError
    };
    // Adapter receives its own object; mutation cannot corrupt output or bridge state.
    if(this.adapter) {
      try { this.adapter.render(structuredClone(result)); this.adapterError=null; }
      catch(error) { this.adapterError=String(error?.message??error); }
    }
    result.adapter_error=this.adapterError;
    return result;
  }
  dispose() { this.adapter?.dispose?.(); this.adapter=null; this.resetInput(); this.disposed=true; }
}

// Expression-only steps intentionally preserve the conversation state.
export const DEMO_STEPS = Object.freeze([
  {label:'idle', conversation_state:'idle', expression:'neutral', volume:0},
  {label:'listening', conversation_state:'listening', expression:'neutral', volume:0},
  {label:'speaking', conversation_state:'speaking', expression:'neutral', volume:0.65},
  {label:'amused', conversation_state:'speaking', expression:'amused', volume:0.65},
  {label:'listening', conversation_state:'listening', expression:'amused', volume:0},
  {label:'concerned', conversation_state:'listening', expression:'concerned', volume:0},
  {label:'speaking', conversation_state:'speaking', expression:'concerned', volume:0.6},
  {label:'annoyed', conversation_state:'speaking', expression:'annoyed', volume:0.5},
  {label:'idle', conversation_state:'idle', expression:'annoyed', volume:0}
]);
export function demoFrame(elapsedMs, timestamp) {
  const index=Math.floor(Math.max(0,elapsedMs)/2500)%DEMO_STEPS.length;
  const step=DEMO_STEPS[index];
  const modulation=step.volume?(0.35+0.65*Math.abs(Math.sin(elapsedMs/220))):0;
  return {index,label:step.label,frame:{conversation_state:step.conversation_state,
    expression:step.expression,volume:step.volume*modulation,timestamp}};
}
