// Original-photo local resampling only. No generated pixels, teeth or face assets.
// Coordinates are specific to the unchanged 1448x1086 source photograph.
const regions=[{x:990,y:380,rx:43,ry:25,a:-.36,kind:'eye',band:6},
 {x:1105,y:329,rx:42,ry:27,a:-.48,kind:'eye',band:7},
 {x:1090,y:463,rx:65,ry:40,a:-.31,kind:'mouth',band:7}];
const clamp=v=>Math.max(0,Math.min(1,v));
export function createFaceMotion({random=Math.random}={}){
 let elapsed=0,nextBlink=5+random()*4,blinkStart=-1,mouth=0,smile=0,gaze=0;
 return {step({dt,state,volume,expression,reduced=false}){
  dt=Math.min(50,Math.max(0,dt));elapsed+=dt;
  if(elapsed>=nextBlink*1000){blinkStart=elapsed;nextBlink=elapsed/1000+5+random()*5;}
  const t=blinkStart<0?1000:elapsed-blinkStart;
  const blink=t<80?t/80:t<120?1:t<260?1-(t-120)/140:0;
  const target=state==='speaking'?clamp((volume-.025)/.65):0;
  mouth+=(target-mouth)*(1-Math.exp(-dt/(target>mouth?90:200)));
  smile+=((['small_smile','soft_smile'].includes(expression)?.65:0)-smile)*(1-Math.exp(-dt/300));
  gaze+=((state==='listening'?.25*Math.sin(elapsed/1700):0)-gaze)*(1-Math.exp(-dt/400));
  return {blink:reduced?0:clamp(blink),mouth:reduced?0:mouth,smile:reduced?0:smile,gaze:reduced?0:gaze,
   mouthPose:mouth<.08?'mouth_closed':mouth<.42?'mouth_small':'mouth_open'};
 },reset(){mouth=0;smile=0;gaze=0;elapsed=0;blinkStart=-1;nextBlink=5+random()*4;}};
}
export function paintPhotoFace(ctx,source,motion){
 const {width:w,height:h,data}=source;
 // Never apply these landmarks to a different photograph/size.
 if(w!==1448||h!==1086)return false;
 ctx.clearRect(0,0,w,h);
 if(!motion.blink&&!motion.mouth&&!motion.smile&&!motion.gaze)return true;
 for(const r of regions){
  const rad=Math.ceil(Math.hypot(r.rx,r.ry)),left=r.x-rad,top=r.y-rad,size=rad*2;
  const out=ctx.createImageData(size,size),c=Math.cos(r.a),s=Math.sin(r.a);
  for(let j=0;j<size;j++)for(let i=0;i<size;i++){
   const dx=left+i-r.x,dy=top+j-r.y,u=dx*c+dy*s,v=-dx*s+dy*c;
   const nx=u/r.rx,ny=v/r.ry,fall=Math.max(0,1-nx*nx-ny*ny);
   if(!fall)continue;
   let su=u,sv=v;
   if(r.kind==='eye'){
    const strength=Math.pow(Math.max(0,1-nx*nx),2),scale=1-.9*motion.blink*strength;
    const a=Math.abs(v),band=r.band*scale;
    const mapped=a<band?a/scale:r.band+(a-band)*(r.ry-r.band)/(r.ry-band);
    sv=Math.sign(v)*mapped;
    su-=motion.gaze*fall;
   }else{
    // Stretch the existing lip texture by a few source pixels only.
    sv=v/(1+.45*motion.mouth*fall*fall);
    sv+=motion.smile*1.4*nx*nx*fall;
    sv-=motion.mouth*.6*fall;
   }
   const x=Math.max(0,Math.min(w-2,r.x+su*c-sv*s)),y=Math.max(0,Math.min(h-2,r.y+su*s+sv*c));
   const x0=Math.floor(x),y0=Math.floor(y),fx=x-x0,fy=y-y0,k=(j*size+i)*4;
   for(let ch=0;ch<3;ch++){const p=(y0*w+x0)*4+ch;out.data[k+ch]=(data[p]*(1-fx)+data[p+4]*fx)*(1-fy)+(data[p+w*4]*(1-fx)+data[p+w*4+4]*fx)*fy;}
   out.data[k+3]=255;
  }
  // Transparent pixels around each patch preserve every other source pixel.
  ctx.putImageData(out,left,top);
 }
 return true;
}
export function attachPhotoFace(image){
 const canvas=document.createElement('canvas');canvas.width=1448;canvas.height=1086;
 canvas.setAttribute('aria-hidden','true');Object.assign(canvas.style,{position:'absolute',inset:'0',width:'100%',height:'100%',objectFit:'contain',pointerEvents:'none',transformOrigin:'65% 65%'});
 image.parentElement.style.position='relative';image.after(canvas);
 const scratch=document.createElement('canvas');scratch.width=1448;scratch.height=1086;
 const read=scratch.getContext('2d',{willReadFrequently:true}),ctx=canvas.getContext('2d');let pixels=null;
 function load(){if(image.naturalWidth!==1448||image.naturalHeight!==1086)return;try{read.drawImage(image,0,0);pixels=read.getImageData(0,0,1448,1086);}catch{pixels=null;}}
 image.addEventListener('load',load);if(image.complete)load();
 return {draw(motion){if(pixels)paintPhotoFace(ctx,pixels,motion);canvas.style.transform=image.style.transform;canvas.hidden=image.hidden;},clear(){ctx.clearRect(0,0,1448,1086);canvas.style.transform='none';},dispose(){canvas.remove();image.removeEventListener('load',load);}};
}
