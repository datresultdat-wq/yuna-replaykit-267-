import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {AvatarControlBridge} from './control-bridge.mjs';
import {createRendererAdapter} from './runtime-renderer.mjs';
import {createTemporary2DRenderer} from './temporary-2d-renderer.mjs';
import {createCaptureInput} from './live-capture-input.mjs';
let now=100000;const image={style:{},dataset:{}},bridge=new AvatarControlBridge({timeoutMs:800});
bridge.setAdapter(createRendererAdapter(createTemporary2DRenderer({image,now:()=>now})));
const input=createCaptureInput(bridge,{now:()=>now});let active=0,idle=0,unknown=0;
for(const f of readFileSync(process.argv[2],'utf8').trim().split('\n').map(JSON.parse)){
 now=f.timestamp;assert.equal(input.receive(f).ok,true);const s=bridge.tick(now);
 if(f.state===1){active++;assert.equal(s.conversation_state,'speaking');assert.equal(image.dataset.speaking,'true');}
 if(f.state===0){idle++;assert.equal(s.conversation_state,'idle');}
 if(f.state===-1){unknown++;assert.equal(s.input_status,'unknown');}
 assert.ok(s.volume>=0&&s.volume<=1);assert.match(image.style.transform,/translate3d/);
 assert.equal(input.receive(f).ok,false);
}
assert.ok(active>0&&idle>0&&unknown>0);
assert.equal(input.receive({source:'microphone',sequence:100,state:1,volume:1,timestamp:now}).ok,false);
assert.equal(input.receive({source:'system_audio',sequence:100,state:1,volume:1,timestamp:now-1000}).ok,false);
assert.equal(input.receive({source:'system_audio',sequence:101,state:1,volume:1,timestamp:now+5000}).ok,false);
assert.equal(input.receive({source:'system_audio',sequence:102,state:1,volume:NaN,timestamp:now}).ok,false);
assert.equal(input.receive({source:'system_audio',sequence:103,state:1,volume:.5,timestamp:++now}).ok,true);
bridge.tick(now);now+=801;assert.equal(bridge.tick(now).input_status,'unknown');
console.log(JSON.stringify({pass:true,frames:40,active,idle,unknown,checks:['PCM→RMS→gate→local adapter→unchanged bridge→2D','replay','invalid input','wrong source','stale/future','watchdog']}));
