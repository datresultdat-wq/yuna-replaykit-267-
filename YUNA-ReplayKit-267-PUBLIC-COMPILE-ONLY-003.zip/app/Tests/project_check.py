from pathlib import Path
import plistlib,hashlib
r=Path(__file__).resolve().parents[1]
project=plistlib.loads((r/'YunaCapture.xcodeproj/project.pbxproj').read_bytes());o=project['objects']
targets=[x for x in o.values() if x['isa']=='PBXNativeTarget']
assert len(targets)==2
host=next(x for x in targets if x['productType']=='com.apple.product-type.application')
ext=next(x for x in targets if x['productType']=='com.apple.product-type.app-extension')
assert len(host['dependencies'])==1
assert any(o[p]['isa']=='PBXCopyFilesBuildPhase' and o[p]['dstSubfolderSpec']=='13' for p in host['buildPhases'])
info=plistlib.loads((r/'Upload/Info.plist').read_bytes())
assert info['NSExtension']['NSExtensionPointIdentifier']=='com.apple.broadcast-services-upload'
assert info['NSExtension']['NSExtensionAttributes']['RPBroadcastProcessMode']=='RPBroadcastProcessModeSampleBuffer'
for t in ['Host','Upload']:
 assert plistlib.loads((r/t/'Entitlements.plist').read_bytes())['com.apple.security.application-groups']==['$(YUNA_APP_GROUP)']
assert hashlib.sha256((r/'Resources/renderer.html').read_bytes()).digest()==hashlib.sha256((r.parent/'YUNA-Live-Capture-Adapter/Live1AudioProbe.swiftpm/Sources/Resources/renderer.html').read_bytes()).digest()
assert (r/'Shared/AudioGate.swift').read_bytes()==(r.parent/'YUNA-Live-Capture-Adapter/Live1AudioProbe.swiftpm/Sources/AudioGate.swift').read_bytes()
code=(r/'Upload/SampleHandler.swift').read_text()
assert 'guard sampleBufferType == .audioApp else{return}' in code
assert 'sampleBufferType == .audioMic {discarded+=1;return}' in code
assert 'AVAudioSession' not in code
print('PASS: target graph, embedded extension, extension attributes, group consistency, exact renderer/gate reuse, source guards (static; NOT Swift compile)')
