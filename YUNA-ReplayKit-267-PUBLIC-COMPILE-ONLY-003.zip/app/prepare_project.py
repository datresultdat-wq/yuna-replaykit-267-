"""Generate a conventional host + Broadcast Upload Extension project. No signing or install."""
from pathlib import Path
import plistlib,hashlib,re
root=Path(__file__).parent
source=root.parent/'YUNA-Live-Capture-Adapter/Live1AudioProbe.swiftpm/Sources/CaptureMeter.swift'
if source.exists():
 text=source.read_text();start=text.index('        guard CMSampleBufferIsValid(sample)');end=text.index('        bufferCount += 1',start)
 body=text[start:end].replace('else { return }','else { return nil }')
 body=re.sub(r'            stop\("未対応のPCM形式：音声取得の検証を中止"\)\n            return', '            return nil',body)
 body=body.replace('stop("不正な音声サンプルのため中止"); return','return nil')
 body=body.replace('        rms = sqrt(squares/Double(total))','        return sqrt(squares/Double(total))')
 (root/'Shared/PCMReader.swift').write_text('import Foundation\nimport CoreMedia\nimport AudioToolbox\n// Extracted from existing CaptureMeter; algorithm unchanged.\nenum PCMReader {\n static func rms(_ sample:CMSampleBuffer)->Double? {\n'+body+' }\n}\n')
def write(path,obj):
 p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(plistlib.dumps(obj,sort_keys=False))
common={'CFBundleExecutable':'$(EXECUTABLE_NAME)','CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleName':'$(PRODUCT_NAME)','CFBundleVersion':'1','CFBundleShortVersionString':'0.1','YunaAppGroup':'$(YUNA_APP_GROUP)'}
write('Host/Info.plist',dict(common,CFBundlePackageType='APPL',YunaUploadBundle='$(PRODUCT_BUNDLE_IDENTIFIER).Upload',UILaunchScreen={},UISupportedInterfaceOrientations=['UIInterfaceOrientationPortrait','UIInterfaceOrientationPortraitUpsideDown','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight']))
write('Upload/Info.plist',dict(common,CFBundlePackageType='XPC!',NSExtension={'NSExtensionPointIdentifier':'com.apple.broadcast-services-upload','NSExtensionPrincipalClass':'$(PRODUCT_MODULE_NAME).SampleHandler','NSExtensionAttributes':{'RPBroadcastProcessMode':'RPBroadcastProcessModeSampleBuffer'}}))
for target in ['Host','Upload']:write(target+'/Entitlements.plist',{'com.apple.security.application-groups':['$(YUNA_APP_GROUP)']})
objs={}
def uid(name):return hashlib.sha256(name.encode()).hexdigest()[:24].upper()
def add(identifier,isa,**values):key=uid(identifier);objs[key]=dict(isa=isa,**values);return key
def configs(name,settings):
 ids=[add(name+mode,'XCBuildConfiguration',name=mode,buildSettings=dict(settings,SWIFT_OPTIMIZATION_LEVEL='-Onone' if mode=='Debug' else '-O')) for mode in ['Debug','Release']]
 return add(name+'config','XCConfigurationList',buildConfigurations=ids,defaultConfigurationIsVisible='0',defaultConfigurationName='Debug')
files={}
for path in ['Host/ProbeApp.swift','Host/LocalRenderer.swift','Shared/FrameStore.swift','Shared/AudioGate.swift','Shared/PCMReader.swift','Upload/SampleHandler.swift','Resources/renderer.html']:
 files[path]=add(path,'PBXFileReference',path=path,sourceTree='<group>',lastKnownFileType='sourcecode.swift' if path.endswith('swift') else 'text.html')
hostProduct=add('app','PBXFileReference',path='YunaCapture.app',sourceTree='BUILT_PRODUCTS_DIR',explicitFileType='wrapper.application')
extProduct=add('ext','PBXFileReference',path='YunaUpload.appex',sourceTree='BUILT_PRODUCTS_DIR',explicitFileType='wrapper.app-extension')
products=add('products','PBXGroup',name='Products',sourceTree='<group>',children=[hostProduct,extProduct])
main=add('main','PBXGroup',sourceTree='<group>',children=list(files.values())+[products])
def phase(name,isa,paths):return add(name,isa,buildActionMask='2147483647',runOnlyForDeploymentPostprocessing='0',files=[add(name+p,'PBXBuildFile',fileRef=files[p]) for p in paths])
shared={'SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'16.0','SWIFT_VERSION':'5.0','TARGETED_DEVICE_FAMILY':'2','CODE_SIGN_STYLE':'Automatic','YUNA_APP_GROUP':'group.local.yuna.capture','GENERATE_INFOPLIST_FILE':'NO','LD_RUNPATH_SEARCH_PATHS':['$(inherited)','@executable_path/Frameworks']}
ext=add('uploadTarget','PBXNativeTarget',name='YunaUpload',productName='YunaUpload',productReference=extProduct,productType='com.apple.product-type.app-extension',buildConfigurationList=configs('upload',dict(shared,PRODUCT_BUNDLE_IDENTIFIER='local.yuna.capture.Upload',PRODUCT_NAME='YunaUpload',INFOPLIST_FILE='Upload/Info.plist',CODE_SIGN_ENTITLEMENTS='Upload/Entitlements.plist',APPLICATION_EXTENSION_API_ONLY='YES',SKIP_INSTALL='YES')),buildPhases=[phase('extSources','PBXSourcesBuildPhase',['Shared/FrameStore.swift','Shared/AudioGate.swift','Shared/PCMReader.swift','Upload/SampleHandler.swift']),phase('extFramework','PBXFrameworksBuildPhase',[])],buildRules=[],dependencies=[])
proxy=add('proxy','PBXContainerItemProxy',containerPortal=uid('project'),proxyType='1',remoteGlobalIDString=ext,remoteInfo='YunaUpload')
dep=add('dependency','PBXTargetDependency',target=ext,targetProxy=proxy)
embed=add('embedFile','PBXBuildFile',fileRef=extProduct,settings={'ATTRIBUTES':['RemoveHeadersOnCopy']})
copy=add('embed','PBXCopyFilesBuildPhase',name='Embed App Extensions',buildActionMask='2147483647',dstPath='',dstSubfolderSpec='13',files=[embed],runOnlyForDeploymentPostprocessing='0')
host=add('hostTarget','PBXNativeTarget',name='YunaCapture',productName='YunaCapture',productReference=hostProduct,productType='com.apple.product-type.application',buildConfigurationList=configs('host',dict(shared,PRODUCT_BUNDLE_IDENTIFIER='local.yuna.capture',PRODUCT_NAME='YunaCapture',INFOPLIST_FILE='Host/Info.plist',CODE_SIGN_ENTITLEMENTS='Host/Entitlements.plist')),buildPhases=[phase('hostSources','PBXSourcesBuildPhase',['Host/ProbeApp.swift','Host/LocalRenderer.swift','Shared/FrameStore.swift']),phase('hostFrameworks','PBXFrameworksBuildPhase',[]),phase('resources','PBXResourcesBuildPhase',['Resources/renderer.html']),copy],buildRules=[],dependencies=[dep])
project=add('project','PBXProject',attributes={'LastUpgradeCheck':'2600'},buildConfigurationList=configs('project',{}),compatibilityVersion='Xcode 14.0',developmentRegion='en',knownRegions=['en','Base'],mainGroup=main,productRefGroup=products,projectDirPath='',projectRoot='',targets=[host,ext])
write('YunaCapture.xcodeproj/project.pbxproj',dict(archiveVersion='1',classes={},objectVersion='56',objects=objs,rootObject=project))
assert all(p.exists() for p in [root/f for f in files])
print('Host + extension project generated; NOT compiled or signed')
