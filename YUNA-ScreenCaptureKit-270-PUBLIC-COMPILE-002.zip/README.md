# YUNA ScreenCaptureKit iPadOS 27 PoC 001

Main path for iPadOS 27:

ChatGPT app / native GPT-Live-1 → ScreenCaptureKit full-display system audio → CMSampleBuffer → existing PCM/RMS gate → Renderer 28.

The ReplayKit 26.7 build remains a separate fallback baseline. This package intentionally removes the Broadcast Upload Extension and App Group dependency from the host target.

This public compile-only package uses a placeholder renderer image and contains no Apple credentials.


## 002 compile fixes
- Add AudioGate.swift and PCMReader.swift to host target sources.
- Use iOS 27 Swift names `SCContentSharingPicker.add(_:)` / `remove(_:)`.
- Remove macOS-only `minimumFrameInterval`.
