import json, os, plistlib, sys
app=sys.argv[1]
with open(os.path.join(app,'Info.plist'),'rb') as f: info=plistlib.load(f)
assert info.get('CFBundleIdentifier')=='local.yuna.capture'
assert 'screen-capture' in info.get('UIBackgroundModes',[])
assert info.get('NSScreenCaptureUsageDescription')
assert not os.path.exists(os.path.join(app,'PlugIns','YunaUpload.appex'))
print(json.dumps({
 'host':info.get('CFBundleIdentifier'),
 'capture':'ScreenCaptureKit',
 'background_screen_capture':True,
 'broadcast_extension_embedded':False,
 'packaging':'PASS',
 'signing':'NOT VERIFIED',
 'installable':False,
 'native_live1':'NOT TESTED'
},ensure_ascii=False,indent=2))
