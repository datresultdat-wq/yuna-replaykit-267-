#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
xcodebuild -version
xcodebuild -project app/YunaCapture.xcodeproj -scheme YunaCapture -configuration Release -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO build
APP='build/DerivedData/Build/Products/Release-iphoneos/YunaCapture.app'
test -d "$APP"
test -f "$APP/YunaCapture"
# ScreenCaptureKit path intentionally has no Broadcast Upload Extension.
if [ -e "$APP/PlugIns/YunaUpload.appex" ]; then
  echo 'ERROR: legacy ReplayKit extension unexpectedly embedded' >&2; exit 1
fi
echo 'ScreenCaptureKit iOS 27 unsigned compile PASS'
