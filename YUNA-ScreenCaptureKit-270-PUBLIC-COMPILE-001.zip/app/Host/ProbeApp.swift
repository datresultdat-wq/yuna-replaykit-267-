import SwiftUI
import ScreenCaptureKit
import CoreMedia
import Foundation

@main
struct ProbeApp: App {
    var body: some Scene { WindowGroup { ProbeView() } }
}

@available(iOS 27.0, *)
@MainActor
final class ScreenAudioCapture: NSObject, ObservableObject, SCContentSharingPickerObserver, SCStreamOutput, SCStreamDelegate {
    @Published var frame = CaptureFrame()
    @Published var status = "未開始：画面全体を選択してください"
    @Published var audioBufferCount = 0

    private let picker = SCContentSharingPicker.shared
    private let audioQueue = DispatchQueue(label: "yuna.sck.audio")
    private var stream: SCStream?
    private var gate = AudioGate()
    private var sequence = 0
    private var timer: DispatchSourceTimer?

    override init() {
        super.init()
        var config = SCContentSharingPickerConfiguration()
        config.showsMicrophoneControl = false
        picker.defaultConfiguration = config
        picker.addObserver(self)
        picker.isActive = true
    }

    deinit {
        picker.removeObserver(self)
        timer?.cancel()
    }

    func presentPicker() {
        status = "Appleの共有ピッカー待ち"
        picker.present()
    }

    func stop() {
        let current = stream
        stream = nil
        timer?.cancel(); timer = nil
        audioQueue.async { [weak self] in self?.gate = AudioGate() }
        Task {
            try? await current?.stopCapture()
            await MainActor.run {
                self.status = "停止"
                self.publish(state: -1, volume: 0)
            }
        }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didUpdateWith filter: SCContentFilter, for stream: SCStream?) {
        Task { @MainActor in
            await self.start(with: filter)
        }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didCancelFor stream: SCStream?) {
        Task { @MainActor in self.status = "共有選択をキャンセル" }
    }

    nonisolated func contentSharingPickerStartDidFailWithError(_ error: any Error) {
        Task { @MainActor in self.status = "共有ピッカー失敗: \(error.localizedDescription)" }
    }

    private func start(with filter: SCContentFilter) async {
        if let old = stream { try? await old.stopCapture() }

        let config = SCStreamConfiguration()
        config.capturesAudio = true
        config.excludesCurrentProcessAudio = true
        config.width = 16
        config.height = 16
        config.minimumFrameInterval = CMTime(value: 1, timescale: 5)

        let newStream = SCStream(filter: filter, configuration: config, delegate: self)
        do {
            // Apple iOS 27 sample attaches a screen output for every stream.
            try newStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: audioQueue)
            // System audio from the selected full display arrives here.
            try newStream.addStreamOutput(self, type: .audio, sampleHandlerQueue: audioQueue)
            self.stream = newStream
            self.gate = AudioGate()
            self.audioBufferCount = 0
            startTimer()
            try await newStream.startCapture()
            status = "Capture中：ChatGPT純正Live1を開始"
        } catch {
            self.stream = nil
            timer?.cancel(); timer = nil
            status = "Capture開始失敗: \(error.localizedDescription)"
            publish(state: -1, volume: 0)
        }
    }

    private func startTimer() {
        timer?.cancel()
        let t = DispatchSource.makeTimerSource(queue: audioQueue)
        t.schedule(deadline: .now(), repeating: .milliseconds(100))
        t.setEventHandler { [weak self] in
            guard let self else { return }
            self.gate.tick(ProcessInfo.processInfo.systemUptime)
            let state = self.gate.state
            let volume = self.gate.level
            Task { @MainActor in self.publish(state: state, volume: volume) }
        }
        timer = t
        t.resume()
    }

    nonisolated func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .audio, let rms = PCMReader.rms(sampleBuffer) else { return }
        audioQueue.async { [weak self] in
            guard let self else { return }
            self.gate.feed(rms, ProcessInfo.processInfo.systemUptime)
            let state = self.gate.state
            let volume = self.gate.level
            Task { @MainActor in
                self.audioBufferCount += 1
                self.status = "system audio受信中"
                self.publish(state: state, volume: volume)
            }
        }
    }

    nonisolated func stream(_ stream: SCStream, didStopWithError error: any Error) {
        Task { @MainActor in
            self.status = "Stream停止: \(error.localizedDescription)"
            self.publish(state: -1, volume: 0)
        }
    }

    private func publish(state: Int, volume: Double) {
        let now = Date().timeIntervalSince1970 * 1000
        sequence = max(sequence + 1, Int(now))
        frame = CaptureFrame(state: state, volume: volume, sequence: sequence, timestamp: now)
    }
}

struct ProbeView: View {
    @StateObject private var capture = ScreenAudioCapture()

    var body: some View {
        VStack(spacing: 12) {
            LocalRenderer(frame: capture.frame)
            Text(capture.status).font(.caption)
            Text("system audio buffers: \(capture.audioBufferCount)").monospaced()
            HStack {
                Button("Live1 Capture開始") { capture.presentPicker() }
                    .buttonStyle(.borderedProminent)
                Button("停止") { capture.stop() }
                    .buttonStyle(.bordered)
            }
            Text("Appleの共有ピッカーで『画面全体』を選択後、ChatGPTアプリの純正GPT-Live-1を開始。音声は保存・送信せず、端末内でRMSへ変換します。")
                .font(.caption)
        }
        .padding()
    }
}
